/* ============================================================
   NUVORA — API.JS
   Central fetch wrapper — swap BASE_URL to connect real backend
   ============================================================ */

'use strict';

const API = {
  // ── CONFIG ─────────────────────────────────────────────────
  BASE_URL: 'http://localhost:5000/api', // ← change to real backend URL later
  
  // ── HELPERS ────────────────────────────────────────────────
  _getToken() {
    return localStorage.getItem('nuvora_token') || '';
  },
  
  _headers(extra = {}) {
    return {
      'Content-Type': 'application/json',
      ...(this._getToken() ? { Authorization: `Bearer ${this._getToken()}` } : {}),
      ...extra,
    };
  },
  
  async _request(method, endpoint, body = null) {
    const opts = {
      method,
      headers: this._headers(),
    };
    if (body) opts.body = JSON.stringify(body);
    
    try {
      const res = await fetch(`${this.BASE_URL}${endpoint}`, opts);
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Request failed');
      return { ok: true, data };
    } catch (err) {
      console.error(`[NUVORA API] ${method} ${endpoint}:`, err.message);
      return { ok: false, error: err.message };
    }
  },
  
  get(endpoint) { return this._request('GET', endpoint); },
  post(endpoint, body) { return this._request('POST', endpoint, body); },
  put(endpoint, body) { return this._request('PUT', endpoint, body); },
  patch(endpoint, body) { return this._request('PATCH', endpoint, body); },
  del(endpoint) { return this._request('DELETE', endpoint); },
  
  // ── AUTH ────────────────────────────────────────────────────
  auth: {
    login: (email, password) => API.post('/auth/login', { email, password }),
    register: (data) => API.post('/auth/register', data),
    registerSeller: (data) => API.post('/auth/register-seller', data),
    logout: () => { localStorage.removeItem('nuvora_token');
      localStorage.removeItem('nuvora_user'); },
    me: () => API.get('/auth/me'),
  },
  
  // ── PRODUCTS ────────────────────────────────────────────────
  products: {
    list: (params = {}) => API.get(`/products?${new URLSearchParams(params)}`),
    get: (id) => API.get(`/products/${id}`),
    featured: () => API.get('/products/featured'),
    flashDeals: () => API.get('/products/flash-deals'),
    search: (q, filters = {}) => API.get(`/products/search?q=${encodeURIComponent(q)}&${new URLSearchParams(filters)}`),
    create: (data) => API.post('/products', data),
    update: (id, data) => API.put(`/products/${id}`, data),
    delete: (id) => API.del(`/products/${id}`),
  },
  
  // ── CATEGORIES ──────────────────────────────────────────────
  categories: {
    list: () => API.get('/categories'),
    get: (id) => API.get(`/categories/${id}`),
  },
  
  // ── ORDERS ──────────────────────────────────────────────────
  orders: {
    create: (data) => API.post('/orders', data),
    list: () => API.get('/orders'),
    get: (id) => API.get(`/orders/${id}`),
    updateStatus: (id, status) => API.patch(`/orders/${id}/status`, { status }),
    cancel: (id) => API.patch(`/orders/${id}/cancel`),
  },
  
  // ── SELLER ──────────────────────────────────────────────────
  seller: {
    dashboard: () => API.get('/seller/dashboard'),
    products: () => API.get('/seller/products'),
    orders: () => API.get('/seller/orders'),
    earnings: () => API.get('/seller/earnings'),
    updateStore: (data) => API.put('/seller/store', data),
  },
  
  // ── ADMIN ───────────────────────────────────────────────────
  admin: {
    dashboard: () => API.get('/admin/dashboard'),
    users: () => API.get('/admin/users'),
    sellers: () => API.get('/admin/sellers'),
    approveSeller: (id) => API.patch(`/admin/sellers/${id}/approve`),
    rejectSeller: (id) => API.patch(`/admin/sellers/${id}/reject`),
    orders: () => API.get('/admin/orders'),
    products: () => API.get('/admin/products'),
    removeProduct: (id) => API.del(`/admin/products/${id}`),
  },
  
  // ── PAYMENTS ────────────────────────────────────────────────
  payments: {
    initiate: (data) => API.post('/payments/initiate', data), // Paystack
    verify: (ref) => API.get(`/payments/verify/${ref}`),
  },
  
  // ── USER ────────────────────────────────────────────────────
  user: {
    profile: () => API.get('/user/profile'),
    updateProfile: (data) => API.put('/user/profile', data),
    addresses: () => API.get('/user/addresses'),
    addAddress: (data) => API.post('/user/addresses', data),
  },
};

// ── SESSION HELPERS ──────────────────────────────────────────
const Auth = {
  setSession(token, user) {
    localStorage.setItem('nuvora_token', token);
    localStorage.setItem('nuvora_user', JSON.stringify(user));
  },
  getUser() {
    const u = localStorage.getItem('nuvora_user');
    return u ? JSON.parse(u) : null;
  },
  isLoggedIn() {
    return !!localStorage.getItem('nuvora_token');
  },
  getRole() {
    const u = this.getUser();
    return u?.role || null; // 'buyer' | 'seller' | 'admin'
  },
  redirectIfNotAuth(fallback = '/pages/auth/login.html') {
    if (!this.isLoggedIn()) window.location.href = fallback;
  },
  redirectIfNotRole(role, fallback = '/index.html') {
    if (this.getRole() !== role) window.location.href = fallback;
  },
};

// ── MOCK DATA (dev only — remove when backend is live) ───────
const MOCK = {
  products: [
    { id: 1, name: 'iPhone 15 Pro Max', price: 1280000, oldPrice: 1450000, image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80', store: 'TechZone NG', rating: 4.8, reviews: 342, discount: 12, category: 'phones' },
    { id: 2, name: 'Samsung Galaxy S24 Ultra', price: 1150000, oldPrice: 1300000, image: 'https://images.unsplash.com/photo-1610945264803-c22b62d2a7b3?w=400&q=80', store: 'GadgetHub', rating: 4.7, reviews: 218, discount: 11, category: 'phones' },
    { id: 3, name: 'Sony WH-1000XM5 Headphones', price: 285000, oldPrice: 340000, image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400&q=80', store: 'AudioWorld', rating: 4.9, reviews: 567, discount: 16, category: 'electronics' },
    { id: 4, name: 'Nike Air Force 1 Low', price: 95000, oldPrice: 115000, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80', store: 'KicksFrenzy', rating: 4.6, reviews: 891, discount: 17, category: 'fashion' },
    { id: 5, name: 'MacBook Air M3', price: 1650000, oldPrice: 1800000, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80', store: 'TechZone NG', rating: 4.9, reviews: 203, discount: 8, category: 'electronics' },
    { id: 6, name: 'Dyson V15 Detect', price: 420000, oldPrice: 510000, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80', store: 'HomeElite', rating: 4.8, reviews: 145, discount: 18, category: 'home' },
    { id: 7, name: 'Adidas Ultraboost 23', price: 88000, oldPrice: 110000, image: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=400&q=80', store: 'KicksFrenzy', rating: 4.5, reviews: 432, discount: 20, category: 'fashion' },
    { id: 8, name: 'iPad Pro 12.9" M4', price: 980000, oldPrice: 1100000, image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&q=80', store: 'GadgetHub', rating: 4.8, reviews: 178, discount: 11, category: 'electronics' },
    { id: 9, name: 'L\'Oreal Revitalift Serum', price: 18500, oldPrice: 24000, image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400&q=80', store: 'GlowStore', rating: 4.4, reviews: 654, discount: 23, category: 'beauty' },
    { id: 10, name: 'PS5 Console + Controller', price: 680000, oldPrice: 780000, image: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400&q=80', store: 'GameZone NG', rating: 4.9, reviews: 521, discount: 13, category: 'electronics' },
  ],
  flashDeals: [
    { id: 11, name: 'Tecno Spark 20 Pro', price: 145000, oldPrice: 200000, image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80', store: 'PhoneHub', rating: 4.3, reviews: 312, discount: 28, stock: 72 },
    { id: 12, name: 'JBL Flip 6 Speaker', price: 45000, oldPrice: 70000, image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&q=80', store: 'AudioWorld', rating: 4.7, reviews: 478, discount: 36, stock: 45 },
    { id: 13, name: 'Men\'s Polo Shirt Set', price: 12500, oldPrice: 20000, image: 'https://images.unsplash.com/photo-1598032895397-b9472444bf93?w=400&q=80', store: 'FashionNG', rating: 4.2, reviews: 189, discount: 38, stock: 83 },
    { id: 14, name: 'Portable Power Bank 20K', price: 22000, oldPrice: 35000, image: 'https://images.unsplash.com/photo-1609592806596-b54c43c83e6f?w=400&q=80', store: 'TechZone NG', rating: 4.5, reviews: 267, discount: 37, stock: 31 },
  ]
};