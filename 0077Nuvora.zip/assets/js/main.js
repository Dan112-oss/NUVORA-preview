/* ============================================================
   NUVORA — MAIN.JS (Global Utilities)
   ============================================================ */

'use strict';

// ── NAVBAR SCROLL EFFECT ────────────────────────────────────
const navbar = document.querySelector('.navbar');
if (navbar) {
  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 10);
  });
}

// ── MOBILE MENU ─────────────────────────────────────────────
const mobileToggle = document.querySelector('.nav-mobile-toggle');
const navCats = document.querySelector('.navbar-bottom');
if (mobileToggle && navCats) {
  mobileToggle.addEventListener('click', () => {
    navCats.classList.toggle('mobile-open');
    // Toggle hamburger icon to X
    const isOpen = navCats.classList.contains('mobile-open');
    mobileToggle.innerHTML = isOpen
      ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M18 6L6 18M6 6l12 12"/></svg>`
      : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="22" height="22"><path d="M3 12h18M3 6h18M3 18h18"/></svg>`;
  });
}

// ── SCROLL REVEAL ────────────────────────────────────────────
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// ── HERO SLIDER ──────────────────────────────────────────────
class HeroSlider {
  constructor() {
    this.slides = document.querySelectorAll('.hero-slide');
    this.dots   = document.querySelectorAll('.slider-dot');
    this.prev   = document.querySelector('.slider-arrow.prev');
    this.next   = document.querySelector('.slider-arrow.next');
    this.current = 0;
    this.timer   = null;
    if (!this.slides.length) return;
    this.init();
  }

  init() {
    this.prev?.addEventListener('click', () => this.go(this.current - 1));
    this.next?.addEventListener('click', () => this.go(this.current + 1));
    this.dots.forEach((d, i) => d.addEventListener('click', () => this.go(i)));
    this.startAuto();
  }

  go(index) {
    // Remove active from current
    this.slides[this.current].classList.remove('active');
    this.dots[this.current]?.classList.remove('active');
    // Set new index
    this.current = (index + this.slides.length) % this.slides.length;
    // Add active to new current
    this.slides[this.current].classList.add('active');
    this.dots[this.current]?.classList.add('active');
    this.resetAuto();
  }

  startAuto() {
    this.timer = setInterval(() => this.go(this.current + 1), 5000);
  }

  resetAuto() {
    clearInterval(this.timer);
    this.startAuto();
  }
}
new HeroSlider();

// ── COUNTDOWN TIMER ──────────────────────────────────────────
function startCountdown(targetHours = 12) {
  const now  = new Date();
  const end  = new Date(now);
  end.setHours(now.getHours() + targetHours, 0, 0, 0);

  const els = {
    h: document.getElementById('countdown-hours'),
    m: document.getElementById('countdown-minutes'),
    s: document.getElementById('countdown-seconds'),
  };

  if (!els.h) return;

  function update() {
    const diff = end - new Date();
    if (diff <= 0) { clearInterval(iv); return; }
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    els.h.textContent = String(h).padStart(2, '0');
    els.m.textContent = String(m).padStart(2, '0');
    els.s.textContent = String(s).padStart(2, '0');
  }
  update();
  const iv = setInterval(update, 1000);
}
startCountdown(8);

// ── CART SYSTEM ──────────────────────────────────────────────
const Cart = {
  get() {
    return JSON.parse(localStorage.getItem('nuvora_cart') || '[]');
  },
  save(items) {
    localStorage.setItem('nuvora_cart', JSON.stringify(items));
    this.updateBadge();
  },
  add(product) {
    const items = this.get();
    const existing = items.find(i => i.id === product.id);
    if (existing) {
      existing.qty += 1;
    } else {
      items.push({ ...product, qty: 1 });
    }
    this.save(items);
    Toast.show(`"${product.name}" added to cart`, 'success');
  },
  remove(id) {
    const items = this.get().filter(i => i.id !== id);
    this.save(items);
  },
  count() {
    return this.get().reduce((sum, i) => sum + i.qty, 0);
  },
  updateBadge() {
    const badge = document.querySelector('.cart-badge');
    if (badge) {
      const count = this.count();
      badge.textContent = count;
      badge.style.display = count ? 'flex' : 'none';
    }
  }
};

// ── WISHLIST SYSTEM ──────────────────────────────────────────
const Wishlist = {
  get() {
    return JSON.parse(localStorage.getItem('nuvora_wishlist') || '[]');
  },
  save(items) {
    localStorage.setItem('nuvora_wishlist', JSON.stringify(items));
    this.updateBadge();
  },
  toggle(product) {
    const items = this.get();
    const idx   = items.findIndex(i => i.id === product.id);
    if (idx >= 0) {
      items.splice(idx, 1);
      Toast.show('Removed from wishlist', 'info');
    } else {
      items.push(product);
      Toast.show('Added to wishlist ❤️', 'success');
    }
    this.save(items);
    return idx < 0;
  },
  has(id) {
    return this.get().some(i => i.id === id);
  },
  count() { return this.get().length; },
  updateBadge() {
    const badge = document.querySelector('.wishlist-badge');
    if (badge) {
      const count = this.count();
      badge.textContent = count;
      badge.style.display = count ? 'flex' : 'none';
    }
  }
};

// ── TOAST NOTIFICATIONS ──────────────────────────────────────
const Toast = {
  container: null,
  init() {
    if (this.container) return;
    this.container = document.createElement('div');
    this.container.className = 'toast-container';
    document.body.appendChild(this.container);
  },
  show(message, type = 'info', duration = 3000) {
    this.init();
    const toast = document.createElement('div');
    const icons = { success: '✅', error: '❌', info: 'ℹ️' };
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
    this.container.appendChild(toast);
    setTimeout(() => {
      toast.style.animation = 'fadeIn 0.3s ease reverse forwards';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }
};

// ── PRODUCT CARD ACTIONS ─────────────────────────────────────
document.addEventListener('click', (e) => {
  // Add to cart button
  const cartBtn = e.target.closest('[data-action="add-cart"]');
  if (cartBtn) {
    e.preventDefault();
    const card = cartBtn.closest('[data-product]');
    if (card) {
      Cart.add(JSON.parse(card.dataset.product));
    }
  }

  // Wishlist toggle
  const wishBtn = e.target.closest('[data-action="wishlist"]');
  if (wishBtn) {
    e.preventDefault();
    const card = wishBtn.closest('[data-product]');
    if (card) {
      const added = Wishlist.toggle(JSON.parse(card.dataset.product));
      wishBtn.classList.toggle('wishlisted', added);
      wishBtn.innerHTML = added ? '❤️' : '🤍';
    }
  }
});

// ── SEARCH ───────────────────────────────────────────────────
const searchForm = document.querySelector('.nav-search');
if (searchForm) {
  const input = searchForm.querySelector('.nav-search-input');
  const btn   = searchForm.querySelector('.nav-search-btn');
  function doSearch() {
    const q = input?.value.trim();
    if (q) {
      window.location.href = `/pages/buyer/product-listing.html?q=${encodeURIComponent(q)}`;
    }
  }
  btn?.addEventListener('click', doSearch);
  input?.addEventListener('keydown', e => e.key === 'Enter' && doSearch());
}

// ── STATS COUNTER ANIMATION ──────────────────────────────────
function animateCounter(el, target, suffix = '') {
  let start = 0;
  const step = target / 60;
  const timer = setInterval(() => {
    start += step;
    if (start >= target) { start = target; clearInterval(timer); }
    el.textContent = Math.floor(start).toLocaleString() + suffix;
  }, 16);
}

const statsObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el  = entry.target;
    const val = parseFloat(el.dataset.count);
    const sfx = el.dataset.suffix || '';
    animateCounter(el, val, sfx);
    statsObserver.unobserve(el);
  });
}, { threshold: 0.5 });

document.querySelectorAll('[data-count]').forEach(el => statsObserver.observe(el));

// ── INIT ON LOAD ─────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  Cart.updateBadge();
  Wishlist.updateBadge();

  // Mark wishlist buttons for already-wishlisted items
  document.querySelectorAll('[data-action="wishlist"]').forEach(btn => {
    const card = btn.closest('[data-product]');
    if (card) {
      const p = JSON.parse(card.dataset.product);
      if (Wishlist.has(p.id)) {
        btn.classList.add('wishlisted');
        btn.innerHTML = '❤️';
      }
    }
  });
});
